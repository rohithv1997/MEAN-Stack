const dbName = 'meanstack',
const password = 'TTUdTyqUnQ1cMAf5';
const mongoDbCloudUrl = 'mongodb+srv://Rohith:'+password+'@cluster0.enhiv.mongodb.net/'+dbName+'?retryWrites=true&w=majority';
